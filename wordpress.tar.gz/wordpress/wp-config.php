<?php
/**
* The base configuration for WordPress
*
* The wp-config.php creation script uses this file during the installation.
* You don't have to use the web site, you can copy this file to "wp-config.php"
* and fill in the values.
*
* This file contains the following configurations:
*
* * Database settings
* * Secret keys
* * Database table prefix
* * ABSPATH
*
* @link https://wordpress.org/support/article/editing-wp-config-php/
*
* @package WordPress
*/
// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'bullfighters' );
/** Database username */
define( 'DB_USER', 'loken' );
/** Database password */
define( 'DB_PASSWORD', 'r1c4t8e3' );
/** Database hostname */
define( 'DB_HOST', 'localhost' );
/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );
/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**#@+
* Authentication unique keys and salts.
*
* Change these to different unique phrases! You can generate these using
* the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
*
* You can change these at any point in time to invalidate all existing cookies.
* This will force all users to have to log in again.
*
* @since 2.6.0
*/
define('AUTH_KEY',         'Pd`!_O xJ1PnI$#~|P-&+9<)>zk3$(VL</h4r`m|rpsf2Ub U)bB~1SRe By-^v{');
define('SECURE_AUTH_KEY',  'u%[SLN<U!*U[xa<&b?_vSs]Z%eRFbl+o[+KY97K+?I_:&-h9z^wsH+kY%C.K-|HS');
define('LOGGED_IN_KEY',    'C z`/~p>;U<*Qu2B8)LVVtB-u2WU#lMk.Sc<?!.OqZO%GYQU/ZRr)cH_bAeTBovh');
define('NONCE_KEY',        'a2XOB0NExTdG[u+ch|cW|:$-FTr2Gq2`o&NHeVD57:-#Y9Qi@ez U*R q-FNlJNz');
define('AUTH_SALT',        '5]X~A3+LrWsjKKWU#R7pPE(MsHj>b%yTH&b?|r&Y1J#6h5QlsMC^;vV+S bFII&3');
define('SECURE_AUTH_SALT', 'No5M!2yN5ssjg-%RWL0Y/|<)}XDnkp:w(+r6A6l YiY/=]H|yGO.-d+XvO& u1W~');
define('LOGGED_IN_SALT',   'RHQZ(|K^O}IK^Wzlt~:aXV{Tg1dp|{GhBw%<=iQhJ:+6rk^|MC<[p[PCRfQ_HLHt');
define('NONCE_SALT',       '~us>ui,HtQD%O!1+!i.`--zI-1Z9*M3=isyHk?ln=^+>w{-@U} ?R!hy{WW$wRit');
/**#@-*/
/**
* WordPress database table prefix.
*
* You can have multiple installations in one database if you give each
* a unique prefix. Only numbers, letters, and underscores please!
*/
$table_prefix = 'gcv_';
/**
* For developers: WordPress debugging mode.
*
* Change this to true to enable the display of notices during development.
* It is strongly recommended that plugin and theme developers use WP_DEBUG
* in their development environments.
*
* For information on other constants that can be used for debugging,
* visit the documentation.
*
* @link https://wordpress.org/support/article/debugging-in-wordpress/
*/
define(	 'WP_DEBUG', false );
/* Add any custom values between this line and the "stop editing" line. */
/* That's all, stop editing! Happy publishing. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
define( 'ABSPATH', __DIR__ . '/' );
}
/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
define('DISABLE_WP_CRON', true);
